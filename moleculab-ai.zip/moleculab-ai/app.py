import streamlit as st
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors, rdMolDescriptors, Draw

st.set_page_config(page_title="MolecuLab AI", page_icon="🧪", layout="wide")

st.markdown("""
<style>
.stApp {background: linear-gradient(135deg, #101827, #172b3a); color: #f4f7fb;}
h1, h2, h3 {color: #65e6cf !important;}
[data-testid="stMetric"] {background: #203648; border: 1px solid #36566a;
padding: 16px; border-radius: 14px;}
.stButton > button {border-radius: 10px; border: 1px solid #65e6cf;}
</style>
""", unsafe_allow_html=True)

MOLECULES = {
    "Aspirin": {
        "smiles": "CC(=O)OC1=CC=CC=C1C(=O)O",
        "category": "Pharmaceutical",
        "description": "Aspirin is used to relieve pain and fever. It also has medically supervised uses in preventing blood clots."
    },
    "Caffeine": {
        "smiles": "Cn1c(=O)c2c(ncn2C)n(C)c1=O",
        "category": "Natural alkaloid",
        "description": "Caffeine is a stimulant found in coffee and tea. It can increase alertness."
    },
    "Paracetamol": {
        "smiles": "CC(=O)NC1=CC=C(O)C=C1",
        "category": "Pharmaceutical",
        "description": "Paracetamol is a medicine used to relieve pain and reduce fever."
    },
    "Ibuprofen": {
        "smiles": "CC(C)CC1=CC=C(C=C1)C(C)C(=O)O",
        "category": "Pharmaceutical",
        "description": "Ibuprofen is a non-steroidal anti-inflammatory medicine used for pain, fever and inflammation."
    },
    "Citric acid": {
        "smiles": "C(C(=O)O)(CC(=O)O)(C(=O)O)O",
        "category": "Organic acid",
        "description": "Citric acid occurs naturally in citrus fruits and is widely used in food."
    },
    "Glucose": {
        "smiles": "C([C@@H]1[C@H]([C@@H]([C@H](C(O1)O)O)O)O)O",
        "category": "Carbohydrate",
        "description": "Glucose is a simple sugar and an important energy source for living cells."
    },
    "Nicotinamide": {
        "smiles": "NC(=O)C1=CC=CN=C1",
        "category": "Vitamin-related compound",
        "description": "Nicotinamide is a form of vitamin B3 involved in normal cellular metabolism."
    },
    "Benzoic acid": {
        "smiles": "O=C(O)C1=CC=CC=C1",
        "category": "Aromatic carboxylic acid",
        "description": "Benzoic acid is an aromatic organic acid used in some food preservation applications."
    }
}

def get_molecule(name):
    mol = Chem.MolFromSmiles(MOLECULES[name]["smiles"])
    return mol

st.title("🧪 MolecuLab AI")
st.caption("Explore molecules. Discover chemistry. Learn interactively.")
st.divider()

st.sidebar.title("🔬 Molecule Explorer")
selected = st.sidebar.selectbox("Choose a molecule", list(MOLECULES.keys()))
st.sidebar.info("Select a molecule to explore its structure, molecular properties and chemistry.")

mol = get_molecule(selected)
info = MOLECULES[selected]

if mol is None:
    st.error("The molecule structure could not be loaded. Check its SMILES notation.")
    st.stop()

left, right = st.columns([1, 1.3], gap="large")
with left:
    st.subheader("Molecular Structure")
    st.image(Draw.MolToImage(mol, size=(500, 400)), use_container_width=True)
    st.markdown("**SMILES notation**")
    st.code(Chem.MolToSmiles(mol), language="text")

with right:
    st.subheader(selected)
    st.write(info["description"])
    st.markdown(f"**Category:** {info['category']}")
    formula = rdMolDescriptors.CalcMolFormula(mol)
    weight = Descriptors.MolWt(mol)
    logp = Descriptors.MolLogP(mol)
    donors = Descriptors.NumHDonors(mol)
    acceptors = Descriptors.NumHAcceptors(mol)
    tpsa = Descriptors.TPSA(mol)
    st.markdown("### Chemical Properties")
    a, b = st.columns(2)
    a.metric("Molecular Formula", formula)
    b.metric("Molecular Weight", f"{weight:.2f} g/mol")
    c, d = st.columns(2)
    c.metric("LogP", f"{logp:.2f}")
    d.metric("H-bond Donors", donors)
    e, f = st.columns(2)
    e.metric("H-bond Acceptors", acceptors)
    f.metric("TPSA", f"{tpsa:.2f} Å²")

st.divider()
st.subheader("💡 Chemistry Insight")
if logp < 0:
    st.write("This molecule has a negative calculated LogP, suggesting a preference for the aqueous phase in the octanol/water partition model.")
elif logp < 2:
    st.write("This molecule has a relatively low-to-moderate calculated LogP.")
else:
    st.write("This molecule has a relatively higher calculated LogP, indicating greater affinity for an octanol-like phase.")
st.caption("Calculated properties are descriptors, not direct measurements of solubility, safety or biological activity.")

st.subheader("📥 Export Molecule Data")
export_data = {
    "Molecule": selected, "Category": info["category"], "Formula": formula,
    "Molecular Weight (g/mol)": round(weight, 4), "LogP": round(logp, 4),
    "Hydrogen Bond Donors": donors, "Hydrogen Bond Acceptors": acceptors,
    "TPSA (Å²)": round(tpsa, 4), "SMILES": Chem.MolToSmiles(mol),
    "Description": info["description"]
}
csv_data = pd.DataFrame([export_data]).to_csv(index=False).encode("utf-8")
st.download_button("Download molecule report (CSV)", data=csv_data,
                   file_name=f"{selected.lower().replace(' ', '_')}_report.csv",
                   mime="text/csv")

st.divider()
st.header("⚖️ Compare Two Molecules")
names = list(MOLECULES.keys())
col1, col2 = st.columns(2)
with col1:
    first = st.selectbox("First molecule", names, index=0)
with col2:
    second = st.selectbox("Second molecule", names, index=1)

if st.button("Compare Molecules", type="primary"):
    m1, m2 = get_molecule(first), get_molecule(second)
    if m1 is None or m2 is None:
        st.error("One of the molecule structures could not be loaded.")
    else:
        comparison = pd.DataFrame({
            "Property": ["Formula", "Molecular Weight (g/mol)", "LogP",
                         "H-bond Donors", "H-bond Acceptors", "TPSA (Å²)"],
            first: [rdMolDescriptors.CalcMolFormula(m1), round(Descriptors.MolWt(m1), 2),
                    round(Descriptors.MolLogP(m1), 2), Descriptors.NumHDonors(m1),
                    Descriptors.NumHAcceptors(m1), round(Descriptors.TPSA(m1), 2)],
            second: [rdMolDescriptors.CalcMolFormula(m2), round(Descriptors.MolWt(m2), 2),
                     round(Descriptors.MolLogP(m2), 2), Descriptors.NumHDonors(m2),
                     Descriptors.NumHAcceptors(m2), round(Descriptors.TPSA(m2), 2)]
        })
        st.dataframe(comparison, use_container_width=True)
        img1, img2 = st.columns(2)
        with img1:
            st.image(Draw.MolToImage(m1, size=(350, 250)), caption=first, use_container_width=True)
        with img2:
            st.image(Draw.MolToImage(m2, size=(350, 250)), caption=second, use_container_width=True)

st.divider()
st.caption("MolecuLab AI | Educational chemistry project | Molecular descriptors are computed using RDKit.")
